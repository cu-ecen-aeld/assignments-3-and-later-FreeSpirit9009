/**
 * requirements:
 * Opens a stream socket bound to port 9000, failing and returning -1 if any of the socket connection steps fail.
 * Listens for and accepts a connection
 * Logs message to the syslog “Accepted connection from xxx” where XXXX is the IP address of the connected client. 
 * Receives data over the connection and appends to file /var/tmp/aesdsocketdata, creating this file if it doesn’t exist.
 * Your implementation should use a newline to separate data packets received.  In other words a packet is considered complete when a newline character is found in the input receive stream, and each newline should result in an append to the /var/tmp/aesdsocketdata file.
 * You may assume the data stream does not include null characters (therefore can be processed using string handling functions).
 * You may assume the length of the packet will be shorter than the available heap size.  In other words, as long as you handle malloc() associated failures with error messages you may discard associated over-length packets.
 * f. Returns the full content of /var/tmp/aesdsocketdata to the client as soon as the received data packet completes.
 * You may assume the total size of all packets sent (and therefore size of /var/tmp/aesdsocketdata) will be less than the size of the root filesystem, however you may not assume this total size of all packets sent will be less than the size of the available RAM for the process heap.
 * g. Logs message to the syslog “Closed connection from XXX” where XXX is the IP address of the connected client.
 * h. Restarts accepting connections from new clients forever in a loop until SIGINT or SIGTERM is received (see below).
 * i. Gracefully exits when SIGINT or SIGTERM is received, completing any open connection operations, closing any open sockets, and deleting the file /var/tmp/aesdsocketdata.
 * Logs message to the syslog “Caught signal, exiting” when SIGINT or SIGTERM is received.
 * 
 * references:
 * - https://beej.us/guide/bgnet/html/split-wide/client-server-background.html
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int main() {

	// TODO: arguments

	// obtain socket file descriptor: STREAM, 0
	//int sockfd = socket();
	
	// bind sizeof struct sockaddr, use getaddrinfo (uses malloc!!) AI passive node null
	//bind(sockfd, addr, addrlen);
	
	// listen
	
	// accept
	
	
	
	int status;
	struct addrinfo hints;
	struct addrinfo *servinfo;  // will point to the results

	memset(&hints, 0, sizeof hints); // make sure the struct is empty
	hints.ai_family = AF_INET;       // use AF_UNSPEC if don't care IPv4 or IPv6
	hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
	hints.ai_flags = AI_PASSIVE;     // fill in my IP for me

	if ((status = getaddrinfo(NULL, "9000", &hints, &servinfo)) != 0) {
		fprintf(stderr, "gai error: %s\n", gai_strerror(status));
		exit(1);
	}
	
	// servinfo now points to a linked list of 1 or more
	// struct addrinfos

	// ... do everything until you don't need servinfo anymore ....
	
	//printf("IP addresses for %s:\n\n", argv[1]);
	printf("IP addresses:\n\n");
    struct addrinfo* p;
    char ipstr[INET6_ADDRSTRLEN];

    for(p = servinfo;p != NULL; p = p->ai_next) {
        void *addr;
        char *ipver;
        struct sockaddr_in *ipv4;
        struct sockaddr_in6 *ipv6;

        // get the pointer to the address itself,
        // different fields in IPv4 and IPv6:
        if (p->ai_family == AF_INET) { // IPv4
            ipv4 = (struct sockaddr_in *)p->ai_addr;
            addr = &(ipv4->sin_addr);
            ipver = "IPv4";
        } else { // IPv6
            ipv6 = (struct sockaddr_in6 *)p->ai_addr;
            addr = &(ipv6->sin6_addr);
            ipver = "IPv6";
        }

        // convert the IP to a string and print it:
        inet_ntop(p->ai_family, addr, ipstr, sizeof ipstr);
        printf("  %s: %s\n", ipver, ipstr);
    }
	
	int sockfd  = socket(servinfo->ai_family, servinfo->ai_socktype, servinfo->ai_protocol);
	if (sockfd  < 0) {
		fprintf(stderr, "socket error: %s\n", strerror(errno));
		exit(1);		
	}
	
	int res = bind(sockfd, servinfo->ai_addr, servinfo->ai_addrlen);
	if (res  < 0) {
		fprintf(stderr, "bind error: %s\n", strerror(errno));
		exit(1);		
	}
	
	res = listen(sockfd, 1); 
	if (res  < 0) {
		fprintf(stderr, "listen error: %s\n", strerror(errno));
		exit(1);		
	}
	
	struct sockaddr_storage their_addr;
	socklen_t addr_size = sizeof their_addr;
    int new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &addr_size);
	(void)new_fd;
	printf("accept returned, addr_size=%u\n", addr_size);
	
	char s[INET6_ADDRSTRLEN];
	inet_ntop(their_addr.ss_family, get_in_addr((struct sockaddr *)&their_addr),
	  s, sizeof s);
    printf("server: got connection from %s\n", s);
    
    char *msg = "Welcome to aesdsocket!";
	int len, bytes_sent;
	len = strlen(msg);
	bytes_sent = send(new_fd/*sockfd*/, msg, len, 0);
	if(bytes_sent < 0) {
		fprintf(stderr, "send error: %s\n", strerror(errno));
		exit(1);		
	}
//	(void)bytes_sent;
	printf("bytes_sent=%u\n",bytes_sent);
	
	freeaddrinfo(servinfo); // free the linked-list

  return 0;
}

