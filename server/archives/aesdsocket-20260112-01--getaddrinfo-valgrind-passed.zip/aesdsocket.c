/**
 * requirements:
 * Opens a stream socket bound to port 9000, failing and returning -1 if any of the socket connection steps fail.
 * Listens for and accepts a connection
 * Logs message to the syslog “Accepted connection from xxx” where XXXX is the IP address of the connected client. 
 * Receives data over the connection and appends to file /var/tmp/aesdsocketdata, creating this file if it doesn’t exist.
 * Your implementation should use a newline to separate data packets received.  In other words a packet is considered complete when a newline character is found in the input receive stream, and each newline should result in an append to the /var/tmp/aesdsocketdata file.
 * You may assume the data stream does not include null characters (therefore can be processed using string handling functions).
 * You may assume the length of the packet will be shorter than the available heap size.  In other words, as long as you handle malloc() associated failures with error messages you may discard associated over-length packets.
 * f. Returns the full content of /var/tmp/aesdsocketdata to the client as soon as the received data packet completes.
 * You may assume the total size of all packets sent (and therefore size of /var/tmp/aesdsocketdata) will be less than the size of the root filesystem, however you may not assume this total size of all packets sent will be less than the size of the available RAM for the process heap.
 * g. Logs message to the syslog “Closed connection from XXX” where XXX is the IP address of the connected client.
 * h. Restarts accepting connections from new clients forever in a loop until SIGINT or SIGTERM is received (see below).
 * i. Gracefully exits when SIGINT or SIGTERM is received, completing any open connection operations, closing any open sockets, and deleting the file /var/tmp/aesdsocketdata.
 * Logs message to the syslog “Caught signal, exiting” when SIGINT or SIGTERM is received.
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main() {

	// TODO: arguments

	// obtain socket file descriptor: STREAM, 0
	//int sockfd = socket();
	
	// bind sizeof struct sockaddr, use getaddrinfo (uses malloc!!) AI passive node null
	//bind(sockfd, addr, addrlen);
	
	// listen
	
	// accept
	
	
	
	int status;
	struct addrinfo hints;
	struct addrinfo *servinfo;  // will point to the results

	memset(&hints, 0, sizeof hints); // make sure the struct is empty
	hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
	hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
	hints.ai_flags = AI_PASSIVE;     // fill in my IP for me

	if ((status = getaddrinfo(NULL, "3490", &hints, &servinfo)) != 0) {
		fprintf(stderr, "gai error: %s\n", gai_strerror(status));
		exit(1);
	}
	
	// servinfo now points to a linked list of 1 or more
	// struct addrinfos

	// ... do everything until you don't need servinfo anymore ....

	freeaddrinfo(servinfo); // free the linked-list

  return 0;
}

